package com.javacgo.wcs.adminserver.modules.system.convert.notice;

import com.javacgo.wcs.adminserver.modules.system.controller.notice.vo.SysNoticeRespVO;
import com.javacgo.wcs.adminserver.modules.system.dal.dataobject.notice.SysNoticeDO;
import com.javacgo.wcs.framework.common.pojo.PageResult;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SysNoticeConvert {
    SysNoticeConvert INSTANCE = Mappers.getMapper(SysNoticeConvert.class);

    PageResult<SysNoticeRespVO> convertPage(PageResult<SysNoticeDO> page);

    SysNoticeRespVO convert(SysNoticeDO bean);

//    SysNoticeDO convert(SysNoticeUpdateReqVO bean);
//
//    SysNoticeDO convert(SysNoticeCreateReqVO bean);

}
