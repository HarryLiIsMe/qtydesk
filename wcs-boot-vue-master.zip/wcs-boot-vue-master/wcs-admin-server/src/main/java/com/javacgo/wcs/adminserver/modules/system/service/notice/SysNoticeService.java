package com.javacgo.wcs.adminserver.modules.system.service.notice;


import com.javacgo.wcs.adminserver.modules.system.controller.notice.vo.SysNoticePageReqVO;
import com.javacgo.wcs.adminserver.modules.system.dal.dataobject.notice.SysNoticeDO;
import com.javacgo.wcs.framework.common.pojo.PageResult;


/**
 * 通知公告 Service 接口
 */
public interface SysNoticeService {

    /**
     * 获得岗位公告公告分页列表
     *
     * @param reqVO 分页条件
     * @return 部门分页列表
     */
    PageResult<SysNoticeDO> pageNotices(SysNoticePageReqVO reqVO);
}
