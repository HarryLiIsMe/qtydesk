package com.javacgo.wcs.adminserver.modules.system.service.auth.impl;


import com.javacgo.wcs.adminserver.modules.system.controller.auth.vo.auth.SysAuthLoginReqVO;
import com.javacgo.wcs.adminserver.modules.system.service.auth.SysUserSessionService;
import com.javacgo.wcs.framework.security.core.LoginUser;
import com.javacgo.wcs.adminserver.modules.system.service.auth.SysAuthService;
import com.javacgo.wcs.adminserver.modules.system.service.common.SysCaptchaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;

import static com.javacgo.wcs.adminserver.modules.system.enums.SysErrorCodeConstants.*;
import static com.javacgo.wcs.framework.common.exception.util.ServiceExceptionUtil.exception;

@Service
@Slf4j
public class SysAuthServiceImpl implements SysAuthService {

    @Resource
    @Lazy // 延迟加载，因为存在相互依赖的问题
    private AuthenticationManager authenticationManager;

    @Resource
    private SysCaptchaService captchaService;

    @Resource
    private SysUserSessionService userSessionService;

    @Override
    public String login(SysAuthLoginReqVO reqVO, String userIp, String userAgent) {
        // 判断验证码是否正确
        this.verifyCaptcha(reqVO.getUsername(), reqVO.getUuid(), reqVO.getCode());
        // 使用账号密码，进行登陆。
        LoginUser loginUser = this.login0(reqVO.getUsername(), reqVO.getPassword());
        //loginUser.setRoleIds(this.getUserRoleIds(loginUser.getId())); // 获取用户角色列表

        // 缓存登陆用户到 Redis 中，返回 sessionId 编号
        return userSessionService.createUserSession(loginUser, userIp, userAgent);
    }
    private void verifyCaptcha(String username, String captchaUUID, String captchaCode) {
        String code = captchaService.getCaptchaCode(captchaUUID);
        // 验证码不存在
        if (code == null) {
            // 创建登陆失败日志（验证码不存在）
            //this.createLoginLog(username, SysLoginResultEnum.CAPTCHA_NOT_FOUND);
            throw exception(AUTH_LOGIN_CAPTCHA_NOT_FOUND);
        }
        // 验证码不正确
        if (!code.equals(captchaCode)) {
            // 创建登陆失败日志（验证码不正确)
           // this.createLoginLog(username, SysLoginResultEnum.CAPTCHA_CODE_ERROR);
            throw exception(AUTH_LOGIN_CAPTCHA_CODE_ERROR);
        }
        // 正确，所以要删除下验证码
        captchaService.deleteCaptchaCode(captchaUUID);
    }

    private LoginUser login0(String username, String password) {
        // 用户验证
        Authentication authentication;
        try {
            // 调用 Spring Security 的 AuthenticationManager#authenticate(...) 方法，使用账号密码进行认证
            // 在其内部，会调用到 loadUserByUsername 方法，获取 User 信息
            authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (BadCredentialsException badCredentialsException) {
           // this.createLoginLog(username, SysLoginResultEnum.BAD_CREDENTIALS);
            throw exception(AUTH_LOGIN_BAD_CREDENTIALS);
        } catch (DisabledException disabledException) {
           // this.createLoginLog(username, SysLoginResultEnum.USER_DISABLED);
            throw exception(AUTH_LOGIN_USER_DISABLED);
        } catch (AuthenticationException authenticationException) {
            log.error("[login0][username({}) 发生未知异常]", username, authenticationException);
          //  this.createLoginLog(username, SysLoginResultEnum.UNKNOWN_ERROR);
            throw exception(AUTH_LOGIN_FAIL_UNKNOWN);
        }
        // 登陆成功
        Assert.notNull(authentication.getPrincipal(), "Principal 不会为空");
       // this.createLoginLog(username, SysLoginResultEnum.SUCCESS);
        return (LoginUser) authentication.getPrincipal();
    }

    @Override
    public LoginUser verifyTokenAndRefresh(String token) {
        return null;
    }

    @Override
    public void logout(String token) {

    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return null;
    }
//    private void createLoginLog(String username, SysLoginResultEnum loginResult) {
//        SysLoginLogCreateReqVO reqVO = new SysLoginLogCreateReqVO();
//        reqVO.setLogType(SysLoginLogTypeEnum.LOGIN_USERNAME.getType());
//        reqVO.setTraceId(TracerUtils.getTraceId());
//        reqVO.setUsername(username);
//        reqVO.setUserAgent(ServletUtils.getUserAgent());
//        reqVO.setUserIp(ServletUtils.getClientIP());
//        reqVO.setResult(loginResult.getResult());
//        loginLogService.createLoginLog(reqVO);
//    }
}
