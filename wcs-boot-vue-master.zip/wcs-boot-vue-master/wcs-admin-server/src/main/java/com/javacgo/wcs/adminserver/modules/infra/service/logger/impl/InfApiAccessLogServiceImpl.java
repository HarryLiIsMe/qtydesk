package com.javacgo.wcs.adminserver.modules.infra.service.logger.impl;



import com.javacgo.wcs.adminserver.modules.infra.controller.logger.vo.apiaccesslog.InfApiAccessLogPageReqVO;
import com.javacgo.wcs.adminserver.modules.infra.convert.logger.InfApiAccessLogConvert;
import com.javacgo.wcs.adminserver.modules.infra.dal.mysql.logger.InfApiAccessLogMapper;
import com.javacgo.wcs.adminserver.modules.infra.dal.dataobject.logger.InfApiAccessLogDO;
import com.javacgo.wcs.adminserver.modules.infra.service.logger.InfApiAccessLogService;
import com.javacgo.wcs.framework.apilog.core.service.dto.ApiAccessLogCreateDTO;
import com.javacgo.wcs.framework.common.pojo.PageResult;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.annotation.Resource;
import java.util.concurrent.Future;

/**
 * API 访问日志 Service 实现类
 */
@Service
@Validated
public class InfApiAccessLogServiceImpl implements InfApiAccessLogService {

    @Resource
    private InfApiAccessLogMapper apiAccessLogMapper;

    @Override
    @Async
    public Future<Boolean> createApiAccessLogAsync(ApiAccessLogCreateDTO createDTO) {
        // 插入
        InfApiAccessLogDO apiAccessLog = InfApiAccessLogConvert.INSTANCE.convert(createDTO);
        int insert = apiAccessLogMapper.insert(apiAccessLog);
        return new AsyncResult<>(insert == 1);
    }

    @Override
    public PageResult<InfApiAccessLogDO> getApiAccessLogPage(InfApiAccessLogPageReqVO pageReqVO) {
        return apiAccessLogMapper.selectPage(pageReqVO);
    }

//    @Override
//    public List<InfApiAccessLogDO> getApiAccessLogList(InfApiAccessLogExportReqVO exportReqVO) {
//        return apiAccessLogMapper.selectList(exportReqVO);
//    }

}
