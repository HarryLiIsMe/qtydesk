package com.javacgo.wcs.adminserver.modules.infra.dal.mysql.logger;

import com.javacgo.wcs.adminserver.modules.infra.dal.dataobject.logger.InfApiErrorLogDO;
import com.javacgo.wcs.framework.mybatis.core.mapper.BaseMapperX;
import org.apache.ibatis.annotations.Mapper;


/**
 * API 错误日志 Mapper
 */
@Mapper
public interface InfApiErrorLogMapper extends BaseMapperX<InfApiErrorLogDO> {
//    default PageResult<InfApiErrorLogDO> selectPage(InfApiErrorLogPageReqVO reqVO) {
//        return selectPage(reqVO, new QueryWrapperX<InfApiErrorLogDO>()
//                .eqIfPresent("user_id", reqVO.getUserId())
//                .eqIfPresent("user_type", reqVO.getUserType())
//                .eqIfPresent("application_name", reqVO.getApplicationName())
//                .likeIfPresent("request_url", reqVO.getRequestUrl())
//                .betweenIfPresent("exception_time", reqVO.getBeginExceptionTime(), reqVO.getEndExceptionTime())
//                .eqIfPresent("process_status", reqVO.getProcessStatus())
//                .orderByDesc("id")
//        );
//    }
//
//    default List<InfApiErrorLogDO> selectList(InfApiErrorLogExportReqVO reqVO) {
//        return selectList(new QueryWrapperX<InfApiErrorLogDO>()
//                .eqIfPresent("user_id", reqVO.getUserId())
//                .eqIfPresent("user_type", reqVO.getUserType())
//                .eqIfPresent("application_name", reqVO.getApplicationName())
//                .likeIfPresent("request_url", reqVO.getRequestUrl())
//                .betweenIfPresent("exception_time", reqVO.getBeginExceptionTime(), reqVO.getEndExceptionTime())
//                .eqIfPresent("process_status", reqVO.getProcessStatus())
//                .orderByDesc("id")
//        );
//    }
}
