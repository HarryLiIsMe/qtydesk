package com.javacgo.wcs.adminserver.modules.infra.convert.logger;

import com.javacgo.wcs.adminserver.modules.infra.dal.dataobject.logger.InfApiErrorLogDO;
import com.javacgo.wcs.framework.apilog.core.service.dto.ApiErrorLogCreateDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * API 错误日志 Convert
 */
@Mapper
public interface InfApiErrorLogConvert {

    InfApiErrorLogConvert INSTANCE = Mappers.getMapper(InfApiErrorLogConvert.class);

    InfApiErrorLogDO convert(ApiErrorLogCreateDTO bean);
//
//    InfApiErrorLogRespVO convert(InfApiErrorLogDO bean);
//
//    PageResult<InfApiErrorLogRespVO> convertPage(PageResult<InfApiErrorLogDO> page);
//
//    List<InfApiErrorLogExcelVO> convertList02(List<InfApiErrorLogDO> list);

}
