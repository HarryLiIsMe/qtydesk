package com.javacgo.wcs.adminserver.framework.monitor.config;

//import de.codecentric.boot.admin.server.config.EnableAdminServer;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//@EnableAdminServer
//public class AdminServerConfiguration {
//}
