package com.javacgo.wcs.adminserver.modules.system.controller.auth;

import com.javacgo.wcs.adminserver.modules.system.controller.auth.vo.auth.SysAuthLoginReqVO;
import com.javacgo.wcs.adminserver.modules.system.controller.auth.vo.auth.SysAuthLoginRespVO;
import com.javacgo.wcs.adminserver.modules.system.service.auth.SysAuthService;
import com.javacgo.wcs.framework.common.pojo.CommonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

import static com.javacgo.wcs.framework.common.pojo.CommonResult.success;
import static com.javacgo.wcs.framework.common.util.servlet.ServletUtils.getClientIP;
import static com.javacgo.wcs.framework.common.util.servlet.ServletUtils.getUserAgent;
@Api(tags = "认证")
@RestController
@RequestMapping("/")
@Validated
public class SysAuthController {

    @Resource
    private SysAuthService authService;

    @PostMapping("/login")
    @ApiOperation("使用账号密码登录")
//    @OperateLog(enable = false) // 避免 Post 请求被记录操作日志
    public CommonResult<SysAuthLoginRespVO> login(@RequestBody @Valid SysAuthLoginReqVO reqVO) {
        String token = authService.login(reqVO, getClientIP(), getUserAgent());
        // 返回结果
        return success(SysAuthLoginRespVO.builder().token(token).build());
    }

}
