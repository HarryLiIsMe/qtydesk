package com.javacgo.wcs.adminserver.modules.system.controller.notice;


import com.javacgo.wcs.adminserver.modules.system.controller.notice.vo.SysNoticePageReqVO;
import com.javacgo.wcs.adminserver.modules.system.controller.notice.vo.SysNoticeRespVO;
import com.javacgo.wcs.adminserver.modules.system.convert.notice.SysNoticeConvert;
import com.javacgo.wcs.adminserver.modules.system.service.notice.SysNoticeService;
import com.javacgo.wcs.framework.common.pojo.CommonResult;
import com.javacgo.wcs.framework.common.pojo.PageResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

import static com.javacgo.wcs.framework.common.pojo.CommonResult.success;

@Api(tags = "通知公告")
@RestController
@RequestMapping("/system/notice")
@Validated
public class SysNoticeController {

    @Resource
    private SysNoticeService noticeService;

    @GetMapping("/page")
    @ApiOperation("获取通知公告列表")
    public CommonResult<PageResult<SysNoticeRespVO>> pageNotices(@Validated SysNoticePageReqVO reqVO) {
        return success(SysNoticeConvert.INSTANCE.convertPage(noticeService.pageNotices(reqVO)));
    }
}
