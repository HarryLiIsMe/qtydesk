package com.javacgo.wcs.adminserver.modules.system.dal.dataobject.user;


import com.javacgo.wcs.framework.mybatis.core.dataobject.BaseDO;

public class SysUserDO  extends BaseDO
{

}
