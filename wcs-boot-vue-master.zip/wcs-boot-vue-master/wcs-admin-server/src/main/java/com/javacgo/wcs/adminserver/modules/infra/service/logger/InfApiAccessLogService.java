package com.javacgo.wcs.adminserver.modules.infra.service.logger;

import com.javacgo.wcs.adminserver.modules.infra.controller.logger.vo.apiaccesslog.InfApiAccessLogPageReqVO;
import com.javacgo.wcs.adminserver.modules.infra.dal.dataobject.logger.InfApiAccessLogDO;
import com.javacgo.wcs.framework.apilog.core.service.ApiAccessLogFrameworkService;
import com.javacgo.wcs.framework.common.pojo.PageResult;


/**
 * API 访问日志 Service 接口
 *
 */
public interface InfApiAccessLogService extends ApiAccessLogFrameworkService {
    /**
     * 获得 API 访问日志分页
     *
     * @param pageReqVO 分页查询
     * @return API 访问日志分页
     */
    PageResult<InfApiAccessLogDO> getApiAccessLogPage(InfApiAccessLogPageReqVO pageReqVO);

    /**
     * 获得 API 访问日志列表, 用于 Excel 导出
     *
     * @param exportReqVO 查询条件
     * @return API 访问日志分页
     */
//    List<InfApiAccessLogDO> getApiAccessLogList(InfApiAccessLogExportReqVO exportReqVO);
}
