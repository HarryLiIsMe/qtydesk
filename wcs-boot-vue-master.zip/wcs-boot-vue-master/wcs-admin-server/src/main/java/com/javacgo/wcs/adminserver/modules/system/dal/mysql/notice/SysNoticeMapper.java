package com.javacgo.wcs.adminserver.modules.system.dal.mysql.notice;

import com.javacgo.wcs.adminserver.modules.system.controller.notice.vo.SysNoticePageReqVO;
import com.javacgo.wcs.adminserver.modules.system.dal.dataobject.notice.SysNoticeDO;
import com.javacgo.wcs.framework.common.pojo.PageResult;
import com.javacgo.wcs.framework.mybatis.core.mapper.BaseMapperX;
import com.javacgo.wcs.framework.mybatis.core.query.QueryWrapperX;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysNoticeMapper extends BaseMapperX<SysNoticeDO> {

    default PageResult<SysNoticeDO> selectPage(SysNoticePageReqVO reqVO) {
        return selectPage(reqVO, new QueryWrapperX<SysNoticeDO>()
                .likeIfPresent("title", reqVO.getTitle())
                .eqIfPresent("status", reqVO.getStatus()));
    }
}
