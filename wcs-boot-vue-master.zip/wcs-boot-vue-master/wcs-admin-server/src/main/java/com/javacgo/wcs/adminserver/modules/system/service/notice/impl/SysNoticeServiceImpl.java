package com.javacgo.wcs.adminserver.modules.system.service.notice.impl;


import com.javacgo.wcs.adminserver.modules.system.controller.notice.vo.SysNoticePageReqVO;
import com.javacgo.wcs.adminserver.modules.system.dal.dataobject.notice.SysNoticeDO;
import com.javacgo.wcs.adminserver.modules.system.dal.mysql.notice.SysNoticeMapper;
import com.javacgo.wcs.adminserver.modules.system.service.notice.SysNoticeService;
import com.javacgo.wcs.framework.common.pojo.PageResult;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 通知公告 Service 实现类
 */
@Service
public class SysNoticeServiceImpl implements SysNoticeService {
    @Resource
    private SysNoticeMapper noticeMapper;
    @Override
    public PageResult<SysNoticeDO> pageNotices(SysNoticePageReqVO reqVO) {
        return noticeMapper.selectPage(reqVO);
    }
}
