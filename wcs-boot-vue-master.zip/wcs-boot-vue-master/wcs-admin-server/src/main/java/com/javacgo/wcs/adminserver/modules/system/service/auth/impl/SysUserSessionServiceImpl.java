package com.javacgo.wcs.adminserver.modules.system.service.auth.impl;

import cn.hutool.core.util.IdUtil;
import com.javacgo.wcs.adminserver.modules.system.controller.auth.vo.session.SysUserSessionPageReqVO;
import com.javacgo.wcs.adminserver.modules.system.dal.dataobject.auth.SysUserSessionDO;
import com.javacgo.wcs.framework.security.core.LoginUser;
import com.javacgo.wcs.adminserver.modules.system.service.auth.SysUserSessionService;
import com.javacgo.wcs.framework.common.pojo.PageResult;
import org.springframework.stereotype.Service;

@Service
public class SysUserSessionServiceImpl implements SysUserSessionService {
    @Override
    public String createUserSession(LoginUser loginUser, String userIp, String userAgent) {
        return null;
    }

    @Override
    public void refreshUserSession(String sessionId, LoginUser loginUser) {

    }

    @Override
    public void deleteUserSession(String sessionId) {

    }

    @Override
    public LoginUser getLoginUser(String sessionId) {
        return null;
    }

    @Override
    public Long getSessionTimeoutMillis() {
        return null;
    }

    @Override
    public PageResult<SysUserSessionDO> getUserSessionPage(SysUserSessionPageReqVO reqVO) {
        return null;
    }

    @Override
    public long clearSessionTimeout() {
        return 0;
    }

    /**
     * 生成 Session 编号，目前采用 UUID 算法
     *
     * @return Session 编号
     */
    private static String generateSessionId() {
        return IdUtil.fastSimpleUUID();
    }
}
