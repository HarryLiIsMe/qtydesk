package com.javacgo.wcs.adminserver.modules.infra.service.logger.impl;

import com.javacgo.wcs.adminserver.modules.infra.dal.mysql.logger.InfApiErrorLogMapper;
import com.javacgo.wcs.adminserver.modules.infra.service.logger.InfApiErrorLogService;
import com.javacgo.wcs.adminserver.modules.infra.convert.logger.InfApiErrorLogConvert;
import com.javacgo.wcs.adminserver.modules.infra.dal.dataobject.logger.InfApiErrorLogDO;
import com.javacgo.wcs.adminserver.modules.infra.enums.logger.InfApiErrorLogProcessStatusEnum;
import com.javacgo.wcs.framework.apilog.core.service.dto.ApiErrorLogCreateDTO;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.concurrent.Future;

/**
 * API 错误日志 Service 实现类
 */
@Service
@Validated
public class InfApiErrorLogServiceImpl implements InfApiErrorLogService {
    @Resource
    private InfApiErrorLogMapper apiErrorLogMapper;
    @Override
    @Async
    public Future<Boolean> createApiErrorLogAsync(@Valid ApiErrorLogCreateDTO createDTO) {
        InfApiErrorLogDO apiErrorLog = InfApiErrorLogConvert.INSTANCE.convert(createDTO);
        apiErrorLog.setProcessStatus(InfApiErrorLogProcessStatusEnum.INIT.getStatus());
        int insert = apiErrorLogMapper.insert(apiErrorLog);
        return new AsyncResult<>(insert == 1);
    }
}
