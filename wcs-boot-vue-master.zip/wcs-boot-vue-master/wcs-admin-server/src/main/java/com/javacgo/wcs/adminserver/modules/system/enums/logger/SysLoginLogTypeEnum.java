package com.javacgo.wcs.adminserver.modules.system.enums.logger;

public enum  SysLoginLogTypeEnum {
}
