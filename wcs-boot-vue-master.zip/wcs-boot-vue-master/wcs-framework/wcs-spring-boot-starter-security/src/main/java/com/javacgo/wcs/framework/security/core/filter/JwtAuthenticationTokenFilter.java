package com.javacgo.wcs.framework.security.core.filter;


import com.javacgo.wcs.framework.security.config.SecurityProperties;
import com.javacgo.wcs.framework.security.core.service.SecurityAuthFrameworkService;
import com.javacgo.wcs.framework.web.core.hanlder.GlobalExceptionHandler;
import lombok.AllArgsConstructor;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
/**
 * JWT 过滤器，验证 token 的有效性
 * 验证通过后，获得 {@link LoginUser} 信息，并加入到 Spring Security 上下文
 */
@AllArgsConstructor
public class JwtAuthenticationTokenFilter extends OncePerRequestFilter {

    private final SecurityProperties securityProperties;
    private final SecurityAuthFrameworkService authService;
    private final GlobalExceptionHandler globalExceptionHandler;
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        // 继续过滤器
        filterChain.doFilter(request, response);
    }
}
