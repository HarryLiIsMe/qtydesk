package com.javacgo.wcs.framework.web.config;

import com.javacgo.wcs.framework.apilog.core.service.ApiErrorLogFrameworkService;
import com.javacgo.wcs.framework.web.core.hanlder.GlobalExceptionHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

@Configuration
@EnableConfigurationProperties({WebProperties.class}/**, XssProperties.class}**/)
public class WCSWebAutoConfiguration  implements WebMvcConfigurer {
    @Resource
    private WebProperties webProperties;
    /**
     * 应用名
     */
    @Value("${spring.application.name}")
    private String applicationName;
    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        // 设置 API 前缀，仅仅匹配 controller 包下的
        configurer.addPathPrefix(webProperties.getApiPrefix(), clazz ->
                clazz.isAnnotationPresent(RestController.class)
                        && clazz.getPackage().getName().startsWith(webProperties.getControllerPackage())); // 仅仅匹配 controller 包
    }
    @Bean
    public GlobalExceptionHandler globalExceptionHandler(ApiErrorLogFrameworkService ApiErrorLogFrameworkService) {
        return new GlobalExceptionHandler(applicationName, ApiErrorLogFrameworkService);

    }


}
