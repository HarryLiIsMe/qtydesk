/**
 * 使用 MyBatis Plus 提升使用 MyBatis 的开发效率
 */
package com.javacgo.wcs.framework.mybatis;
