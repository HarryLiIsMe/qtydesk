package com.javacgo.wcs.framework.common.core;

/**
 * 可生成 Int 数组的接口
 */
public interface IntArrayValuable {

    /**
     * @return int 数组
     */
    int[] array();

}
