-- MySQL dump 10.13  Distrib 5.7.38, for Win64 (x86_64)
--
-- Host: localhost    Database: wcs-boot-vue
-- ------------------------------------------------------
-- Server version	5.7.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inf_api_access_log`
--

DROP TABLE IF EXISTS `inf_api_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inf_api_access_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `trace_id` varchar(64) NOT NULL DEFAULT '' COMMENT '链路追踪编号',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户编号',
  `user_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户类型',
  `application_name` varchar(50) NOT NULL COMMENT '应用名',
  `request_method` varchar(16) NOT NULL DEFAULT '' COMMENT '请求方法名',
  `request_url` varchar(255) NOT NULL DEFAULT '' COMMENT '请求地址',
  `request_params` varchar(8000) NOT NULL DEFAULT '' COMMENT '请求参数',
  `user_ip` varchar(50) NOT NULL COMMENT '用户 IP',
  `user_agent` varchar(512) NOT NULL COMMENT '浏览器 UA',
  `begin_time` datetime NOT NULL COMMENT '开始请求时间',
  `end_time` datetime NOT NULL COMMENT '结束请求时间',
  `duration` int(11) NOT NULL COMMENT '执行时长',
  `result_code` int(11) NOT NULL DEFAULT '0' COMMENT '结果码',
  `result_msg` varchar(512) DEFAULT '' COMMENT '结果提示',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='API 访问日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inf_api_access_log`
--

LOCK TABLES `inf_api_access_log` WRITE;
/*!40000 ALTER TABLE `inf_api_access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `inf_api_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inf_api_error_log`
--

DROP TABLE IF EXISTS `inf_api_error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inf_api_error_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `trace_id` varchar(64) NOT NULL COMMENT '链路追踪编号\n     *\n     * 一般来说，通过链路追踪编号，可以将访问日志，错误日志，链路追踪日志，logger 打印日志等，结合在一起，从而进行排错。',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户编号',
  `user_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户类型',
  `application_name` varchar(50) NOT NULL COMMENT '应用名\n     *\n     * 目前读取 spring.application.name',
  `request_method` varchar(16) NOT NULL COMMENT '请求方法名',
  `request_url` varchar(255) NOT NULL COMMENT '请求地址',
  `request_params` varchar(8000) NOT NULL COMMENT '请求参数',
  `user_ip` varchar(50) NOT NULL COMMENT '用户 IP',
  `user_agent` varchar(512) NOT NULL COMMENT '浏览器 UA',
  `exception_time` datetime NOT NULL COMMENT '异常发生时间',
  `exception_name` varchar(128) NOT NULL DEFAULT '' COMMENT '异常名\n     *\n     * {@link Throwable#getClass()} 的类全名',
  `exception_message` text NOT NULL COMMENT '异常导致的消息\n     *\n     * {@link cn.iocoder.common.framework.util.ExceptionUtil#getMessage(Throwable)}',
  `exception_root_cause_message` text NOT NULL COMMENT '异常导致的根消息\n     *\n     * {@link cn.iocoder.common.framework.util.ExceptionUtil#getRootCauseMessage(Throwable)}',
  `exception_stack_trace` text NOT NULL COMMENT '异常的栈轨迹\n     *\n     * {@link cn.iocoder.common.framework.util.ExceptionUtil#getServiceException(Exception)}',
  `exception_class_name` varchar(512) NOT NULL COMMENT '异常发生的类全名\n     *\n     * {@link StackTraceElement#getClassName()}',
  `exception_file_name` varchar(512) NOT NULL COMMENT '异常发生的类文件\n     *\n     * {@link StackTraceElement#getFileName()}',
  `exception_method_name` varchar(512) NOT NULL COMMENT '异常发生的方法名\n     *\n     * {@link StackTraceElement#getMethodName()}',
  `exception_line_number` int(11) NOT NULL COMMENT '异常发生的方法所在行\n     *\n     * {@link StackTraceElement#getLineNumber()}',
  `process_status` tinyint(4) NOT NULL COMMENT '处理状态',
  `process_time` datetime DEFAULT NULL COMMENT '处理时间',
  `process_user_id` int(11) DEFAULT '0' COMMENT '处理用户编号',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统异常日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inf_api_error_log`
--

LOCK TABLES `inf_api_error_log` WRITE;
/*!40000 ALTER TABLE `inf_api_error_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `inf_api_error_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dept`
--

DROP TABLE IF EXISTS `sys_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_dept` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '部门名称',
  `parent_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '父部门id',
  `sort` int(4) NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `leader` varchar(20) DEFAULT NULL COMMENT '负责人',
  `phone` varchar(11) DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `status` tinyint(4) NOT NULL COMMENT '部门状态（0正常 1停用）',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dept`
--

LOCK TABLES `sys_dept` WRITE;
/*!40000 ALTER TABLE `sys_dept` DISABLE KEYS */;
INSERT INTO `sys_dept` VALUES (100,'芋道源码',0,0,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-06 19:45:52',_binary '\0'),(101,'深圳总公司',100,1,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','1','2021-03-14 20:26:18',_binary '\0'),(102,'长沙分公司',100,2,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-05 17:03:47',_binary '\0'),(103,'研发部门',101,1,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-05 17:03:47',_binary '\0'),(104,'市场部门',101,2,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-05 17:03:47',_binary '\0'),(105,'测试部门',101,3,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-05 17:03:47',_binary '\0'),(106,'财务部门',101,4,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-05 17:03:47',_binary '\0'),(107,'运维部门',101,5,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-05 17:03:47',_binary '\0'),(108,'市场部门',102,1,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-05 17:03:47',_binary '\0'),(109,'财务部门',102,2,'若依','15888888888','ry@qq.com',0,'admin','2021-01-05 17:03:47','','2021-01-05 17:03:47',_binary '\0');
/*!40000 ALTER TABLE `sys_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `name` varchar(50) NOT NULL COMMENT '菜单名称',
  `permission` varchar(100) NOT NULL DEFAULT '' COMMENT '权限标识',
  `menu_type` tinyint(4) NOT NULL COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `parent_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '父菜单ID',
  `path` varchar(200) DEFAULT '' COMMENT '路由地址',
  `icon` varchar(100) DEFAULT '#' COMMENT '菜单图标',
  `component` varchar(255) DEFAULT NULL COMMENT '组件路径',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '菜单状态（0正常 1停用）',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1117 DEFAULT CHARSET=utf8mb4 COMMENT='菜单权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_menu`
--

LOCK TABLES `sys_menu` WRITE;
/*!40000 ALTER TABLE `sys_menu` DISABLE KEYS */;
INSERT INTO `sys_menu` VALUES (1,'系统管理','',1,1,0,'/system','system',NULL,0,'admin','2021-01-05 17:03:48','','2021-01-05 22:34:28',_binary '\0'),(2,'基础设施','',1,2,0,'/infra','monitor',NULL,0,'admin','2021-01-05 17:03:48','','2021-01-20 14:18:35',_binary '\0'),(3,'研发工具','',1,3,0,'/tool','tool',NULL,0,'admin','2021-01-05 17:03:48','','2021-02-06 12:44:42',_binary '\0'),(4,'若依官网','',1,4,0,'http://ruoyi.vip','guide',NULL,0,'admin','2021-01-05 17:03:48','','2021-01-20 21:54:28',_binary ''),(100,'用户管理','system:user:list',2,1,1,'user','user','system/user/index',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:45',_binary '\0'),(101,'角色管理','',2,2,1,'role','peoples','system/role/index',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:04:49',_binary '\0'),(102,'菜单管理','',2,3,1,'menu','tree-table','system/menu/index',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:04:28',_binary '\0'),(103,'部门管理','',2,4,1,'dept','tree','system/dept/index',0,'admin','2021-01-05 17:03:48','1','2021-03-14 20:25:19',_binary '\0'),(104,'岗位管理','',2,5,1,'post','post','system/post/index',0,'admin','2021-01-05 17:03:48','1','2021-03-14 20:38:23',_binary '\0'),(105,'字典管理','',2,6,1,'dict','dict','system/dict/index',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:16:58',_binary '\0'),(106,'配置管理','',2,1,2,'config','edit','infra/config/index',0,'admin','2021-01-05 17:03:48','1','2021-03-10 01:12:10',_binary '\0'),(107,'通知公告','',2,8,1,'notice','message','system/notice/index',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:51:39',_binary '\0'),(108,'审计日志','',1,9,1,'log','log','',0,'admin','2021-01-05 17:03:48','1','2021-04-26 22:34:58',_binary '\0'),(109,'在线用户','system:user-session:list',2,10,1,'user-session','online','system/session/index',0,'admin','2021-01-05 17:03:48','','2021-01-26 08:21:20',_binary '\0'),(110,'定时任务','',2,2,2,'job','job','infra/job/index',0,'admin','2021-01-05 17:03:48','1','2021-03-10 01:25:51',_binary '\0'),(111,'MySQL 监控','',2,4,2,'druid','druid','infra/druid/index',0,'admin','2021-01-05 17:03:48','','2021-02-26 02:18:32',_binary '\0'),(112,'Java 监控','',2,6,2,'admin-server','server','infra/server',0,'admin','2021-01-05 17:03:48','','2021-02-26 02:18:41',_binary '\0'),(113,'Redis 监控','',2,5,2,'redis','redis','infra/redis/index',0,'admin','2021-01-05 17:03:48','','2021-02-26 02:18:37',_binary '\0'),(114,'表单构建','tool:build:list',2,1,3,'build','build','tool/build/index',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:45',_binary '\0'),(115,'代码生成','tool:codegen:query',2,0,3,'codegen','code','tool/codegen/index',0,'admin','2021-01-05 17:03:48','','2021-03-06 03:43:14',_binary '\0'),(116,'系统接口','tool:swagger:list',2,3,3,'swagger','swagger','tool/swagger/index',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:45',_binary '\0'),(500,'操作日志','',2,1,108,'operate-log','form','system/operatelog/index',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:42:56',_binary '\0'),(501,'登录日志','',2,2,108,'login-log','logininfor','system/loginlog/index',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:39:23',_binary '\0'),(1001,'用户查询','system:user:query',3,1,100,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1002,'用户新增','system:user:create',3,2,100,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:21:47',_binary '\0'),(1003,'用户修改','system:user:update',3,3,100,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:21:54',_binary '\0'),(1004,'用户删除','system:user:delete',3,4,100,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:22:03',_binary '\0'),(1005,'用户导出','system:user:export',3,5,100,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1006,'用户导入','system:user:import',3,6,100,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1007,'重置密码','system:user:update-password',3,7,100,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:20:55',_binary '\0'),(1008,'角色查询','system:role:query',3,1,101,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1009,'角色新增','system:role:create',3,2,101,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:05:24',_binary '\0'),(1010,'角色修改','system:role:update',3,3,101,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:05:14',_binary '\0'),(1011,'角色删除','system:role:delete',3,4,101,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 22:05:05',_binary '\0'),(1012,'角色导出','system:role:export',3,5,101,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1013,'菜单查询','system:menu:query',3,1,102,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1014,'菜单新增','system:menu:create',3,2,102,'','#','',0,'admin','2021-01-05 17:03:48','','2021-03-13 15:49:36',_binary '\0'),(1015,'菜单修改','system:menu:update',3,3,102,'','#','',0,'admin','2021-01-05 17:03:48','','2021-03-13 15:49:30',_binary '\0'),(1016,'菜单删除','system:menu:delete',3,4,102,'','#','',0,'admin','2021-01-05 17:03:48','','2021-03-13 15:49:45',_binary '\0'),(1017,'部门查询','system:dept:query',3,1,103,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1018,'部门新增','system:dept:create',3,2,103,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 20:25:30',_binary '\0'),(1019,'部门修改','system:dept:update',3,3,103,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 20:25:37',_binary '\0'),(1020,'部门删除','system:dept:delete',3,4,103,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 20:25:43',_binary '\0'),(1021,'岗位查询','system:post:query',3,1,104,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1022,'岗位新增','system:post:create',3,2,104,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 20:38:34',_binary '\0'),(1023,'岗位修改','system:post:update',3,3,104,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 20:38:41',_binary '\0'),(1024,'岗位删除','system:post:delete',3,4,104,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 20:38:48',_binary '\0'),(1025,'岗位导出','system:post:export',3,5,104,'','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1026,'字典查询','system:dict:query',3,1,105,'#','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1027,'字典新增','system:dict:create',3,2,105,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:19:29',_binary '\0'),(1028,'字典修改','system:dict:update',3,3,105,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:19:36',_binary '\0'),(1029,'字典删除','system:dict:delete',3,4,105,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:19:45',_binary '\0'),(1030,'字典导出','system:dict:export',3,5,105,'#','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1031,'配置查询','infra:config:query',3,1,106,'','','',0,'admin','2021-01-05 17:03:48','','2021-01-20 14:34:00',_binary '\0'),(1032,'配置新增','infra:config:create',3,2,106,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-10 01:12:18',_binary '\0'),(1033,'配置修改','infra:config:update',3,3,106,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-10 01:12:30',_binary '\0'),(1034,'配置删除','infra:config:delete',3,4,106,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-10 01:12:36',_binary '\0'),(1035,'配置导出','infra:config:export',3,5,106,'','','',0,'admin','2021-01-05 17:03:48','','2021-01-20 14:34:19',_binary '\0'),(1036,'公告查询','system:notice:query',3,1,107,'#','#','',0,'admin','2021-01-05 17:03:48','','2021-01-05 22:36:55',_binary '\0'),(1037,'公告新增','system:notice:create',3,2,107,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:51:48',_binary '\0'),(1038,'公告修改','system:notice:update',3,3,107,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:51:55',_binary '\0'),(1039,'公告删除','system:notice:delete',3,4,107,'','','',0,'admin','2021-01-05 17:03:48','1','2021-03-14 21:52:01',_binary '\0'),(1040,'操作查询','system:operate-log:query',3,1,500,'','','',0,'admin','2021-01-05 17:03:48','','2021-01-16 18:28:10',_binary '\0'),(1042,'日志导出','system:operate-log:export',3,2,500,'','','',0,'admin','2021-01-05 17:03:48','','2021-01-16 18:28:23',_binary '\0'),(1043,'登录查询','system:login-log:query',3,1,501,'#','#','',0,'admin','2021-01-05 17:03:48','','2021-01-18 05:29:26',_binary '\0'),(1045,'日志导出','system:login-log:export',3,3,501,'#','#','',0,'admin','2021-01-05 17:03:48','','2021-01-18 05:29:30',_binary '\0'),(1046,'在线查询','system:user-session:list',3,1,109,'','','',0,'admin','2021-01-05 17:03:48','','2021-01-26 08:22:37',_binary '\0'),(1047,'批量强退','monitor:online:batchLogout',3,2,109,'#','#','',0,'admin','2021-01-05 17:03:48','','2021-01-26 08:21:46',_binary ''),(1048,'单条强退','system:user-session:delete',3,3,109,'','','',0,'admin','2021-01-05 17:03:48','','2021-01-26 08:22:54',_binary '\0'),(1049,'任务查询','monitor:job:query',3,1,110,'#','#','',0,'admin','2021-01-05 17:03:48','','2021-02-07 13:01:42',_binary ''),(1050,'任务新增','infra:job:create',3,2,110,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-07 13:01:58',_binary '\0'),(1051,'任务修改','infra:job:update',3,3,110,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-07 13:02:10',_binary '\0'),(1052,'任务删除','infra:job:delete',3,4,110,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-07 13:02:22',_binary '\0'),(1053,'状态修改','infra:job:update',3,5,110,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-07 13:02:38',_binary '\0'),(1054,'任务导出','infra:job:export',3,7,110,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-07 13:02:51',_binary '\0'),(1055,'生成查询','tool:gen:query',3,1,115,'#','#','',0,'admin','2021-01-05 17:03:48','','2021-02-06 21:23:25',_binary ''),(1056,'生成修改','tool:codegen:update',3,2,115,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-06 21:23:41',_binary '\0'),(1057,'生成删除','tool:codegen:delete',3,3,115,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-06 21:24:02',_binary '\0'),(1058,'导入代码','tool:codegen:create',3,2,115,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-06 21:23:50',_binary '\0'),(1059,'预览代码','tool:codegen:preview',3,4,115,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-06 21:24:10',_binary '\0'),(1060,'生成代码','tool:codegen:download',3,5,115,'','','',0,'admin','2021-01-05 17:03:48','','2021-02-06 21:24:20',_binary '\0'),(1063,'设置角色菜单权限','system:permission:assign-role-menu',3,6,101,'','','',0,'','2021-01-06 17:53:44','','2021-01-06 17:55:23',_binary '\0'),(1064,'设置角色数据权限','system:permission:assign-role-data-scope',3,7,101,'','','',0,'','2021-01-06 17:56:31','','2021-01-06 17:56:31',_binary '\0'),(1065,'设置用户角色','system:permission:assign-user-role',3,8,101,'','','',0,'','2021-01-07 10:23:28','','2021-01-07 10:23:28',_binary '\0'),(1066,'获得 Redis 监控信息','infra:redis:get-monitor-info',3,1,113,'','','',0,'','2021-01-26 01:02:31','','2021-01-26 01:02:31',_binary '\0'),(1067,'获得 Redis Key 列表','infra:redis:get-key-list',3,2,113,'','','',0,'','2021-01-26 01:02:52','','2021-01-26 01:02:52',_binary '\0'),(1070,'代码生成示例','tool:test-demo:query',2,0,3,'test-demo','validCode','tool/testDemo/index',0,'','2021-02-06 12:42:49','','2021-03-06 03:45:22',_binary '\0'),(1071,'测试示例表创建','tool:test-demo:create',3,1,1070,'','','',0,'','2021-02-06 12:42:49','','2021-02-06 12:53:47',_binary '\0'),(1072,'测试示例表更新','tool:test-demo:update',3,2,1070,'','','',0,'','2021-02-06 12:42:49','','2021-02-06 12:53:51',_binary '\0'),(1073,'测试示例表删除','tool:test-demo:delete',3,3,1070,'','','',0,'','2021-02-06 12:42:49','','2021-02-06 12:53:58',_binary '\0'),(1074,'测试示例表导出','tool:test-demo:export',3,4,1070,'','','',0,'','2021-02-06 12:42:49','','2021-02-06 12:54:01',_binary '\0'),(1075,'任务触发','infra:job:trigger',3,8,110,'','','',0,'','2021-02-07 13:03:10','','2021-02-07 13:03:10',_binary '\0'),(1076,'数据库文档','',2,5,3,'db-doc','table','tool/dbDoc/index',0,'','2021-02-08 01:41:47','','2021-02-08 01:49:00',_binary '\0'),(1077,'链路追踪','',2,7,2,'skywalking','eye-open','infra/skywalking',0,'','2021-02-08 20:41:31','','2021-02-26 02:18:45',_binary '\0'),(1078,'访问日志','',2,1,1083,'api-access-log','log','infra/apiAccessLog/index',0,'','2021-02-26 01:32:59','1','2021-03-10 01:28:09',_binary '\0'),(1079,'API 访问日志表创建','system:api-access-log:create',3,1,1078,'','','',1,'','2021-02-26 01:32:59','','2021-02-26 02:21:00',_binary ''),(1080,'API 访问日志表更新','system:api-access-log:update',3,2,1078,'','','',1,'','2021-02-26 01:32:59','','2021-02-26 02:21:08',_binary ''),(1081,'API 访问日志表删除','system:api-access-log:delete',3,3,1078,'','','',1,'','2021-02-26 01:32:59','','2021-02-26 02:21:27',_binary ''),(1082,'日志导出','infra:api-access-log:export',3,2,1078,'','','',0,'','2021-02-26 01:32:59','1','2021-03-10 01:28:13',_binary '\0'),(1083,'API 日志','',2,3,2,'log','log',NULL,0,'','2021-02-26 02:18:24','','2021-02-26 02:20:17',_binary '\0'),(1084,'错误日志','infra:api-error-log:query',2,2,1083,'api-error-log','log','infra/apiErrorLog/index',0,'','2021-02-26 07:53:20','','2021-02-26 07:54:40',_binary '\0'),(1085,'日志处理','infra:api-error-log:update-status',3,2,1084,'','','',0,'','2021-02-26 07:53:20','1','2021-03-10 01:28:18',_binary '\0'),(1086,'日志导出','infra:api-error-log:export',3,3,1084,'','','',0,'','2021-02-26 07:53:20','1','2021-03-10 01:28:21',_binary '\0'),(1087,'任务查询','infra:job:query',3,1,110,'','','',0,'1','2021-03-10 01:26:19','1','2021-03-10 01:26:19',_binary '\0'),(1088,'日志查询','infra:api-access-log:query',3,1,1078,'','','',0,'1','2021-03-10 01:28:04','1','2021-03-10 01:29:38',_binary '\0'),(1089,'日志查询','infra:api-error-log:query',3,1,1084,'','','',0,'1','2021-03-10 01:29:09','1','2021-03-10 01:29:09',_binary '\0'),(1090,'文件管理','',2,0,2,'file','upload','infra/file/index',0,'','2021-03-12 20:16:20','1','2021-03-13 11:07:05',_binary '\0'),(1091,'文件查询','infra:file:query',3,1,1090,'','','',0,'','2021-03-12 20:16:20','','2021-03-12 20:16:20',_binary '\0'),(1092,'文件删除','infra:file:delete',3,4,1090,'','','',0,'','2021-03-12 20:16:20','','2021-03-12 20:16:20',_binary '\0'),(1093,'短信管理','',1,11,1,'sms','validCode',NULL,0,'1','2021-04-05 01:10:16','1','2021-04-05 01:11:38',_binary '\0'),(1094,'短信渠道','',2,0,1093,'sms-channel','phone','system/sms/smsChannel',0,'','2021-04-01 11:07:15','1','2021-04-09 23:44:07',_binary '\0'),(1095,'短信渠道查询','system:sms-channel:query',3,1,1094,'','','',0,'','2021-04-01 11:07:15','','2021-04-01 11:07:15',_binary '\0'),(1096,'短信渠道创建','system:sms-channel:create',3,2,1094,'','','',0,'','2021-04-01 11:07:15','','2021-04-01 11:07:15',_binary '\0'),(1097,'短信渠道更新','system:sms-channel:update',3,3,1094,'','','',0,'','2021-04-01 11:07:15','','2021-04-01 11:07:15',_binary '\0'),(1098,'短信渠道删除','system:sms-channel:delete',3,4,1094,'','','',0,'','2021-04-01 11:07:15','','2021-04-01 11:07:15',_binary '\0'),(1100,'短信模板','',2,1,1093,'sms-template','phone','system/sms/smsTemplate',0,'','2021-04-01 17:35:17','1','2021-04-11 19:34:21',_binary '\0'),(1101,'短信模板查询','system:sms-template:query',3,1,1100,'','','',0,'','2021-04-01 17:35:17','','2021-04-01 17:35:17',_binary '\0'),(1102,'短信模板创建','system:sms-template:create',3,2,1100,'','','',0,'','2021-04-01 17:35:17','','2021-04-01 17:35:17',_binary '\0'),(1103,'短信模板更新','system:sms-template:update',3,3,1100,'','','',0,'','2021-04-01 17:35:17','','2021-04-01 17:35:17',_binary '\0'),(1104,'短信模板删除','system:sms-template:delete',3,4,1100,'','','',0,'','2021-04-01 17:35:17','','2021-04-01 17:35:17',_binary '\0'),(1105,'短信模板导出','system:sms-template:export',3,5,1100,'','','',0,'','2021-04-01 17:35:17','','2021-04-01 17:35:17',_binary '\0'),(1106,'发送测试短信','system:sms-template:send-sms',3,6,1100,'','','',0,'1','2021-04-11 00:26:40','1','2021-04-11 00:26:40',_binary '\0'),(1107,'短信日志','',2,2,1093,'sms-log','phone','system/sms/smsLog',0,'','2021-04-11 08:37:05','1','2021-04-11 19:34:25',_binary '\0'),(1108,'短信日志查询','system:sms-log:query',3,1,1107,'','','',0,'','2021-04-11 08:37:05','','2021-04-11 08:37:05',_binary '\0'),(1109,'短信日志导出','system:sms-log:export',3,5,1107,'','','',0,'','2021-04-11 08:37:05','','2021-04-11 08:37:05',_binary '\0'),(1110,'错误码管理','',2,12,1,'error-code','code','system/errorCode/index',0,'','2021-04-13 21:46:42','1','2021-04-22 00:04:35',_binary '\0'),(1111,'错误码查询','system:error-code:query',3,1,1110,'','','',0,'','2021-04-13 21:46:42','','2021-04-13 22:09:37',_binary '\0'),(1112,'错误码创建','system:error-code:create',3,2,1110,'','','',0,'','2021-04-13 21:46:42','','2021-04-13 22:09:43',_binary '\0'),(1113,'错误码更新','system:error-code:update',3,3,1110,'','','',0,'','2021-04-13 21:46:42','','2021-04-13 22:09:47',_binary '\0'),(1114,'错误码删除','system:error-code:delete',3,4,1110,'','','',0,'','2021-04-13 21:46:42','','2021-04-13 22:09:51',_binary '\0'),(1115,'错误码导出','system:error-code:export',3,5,1110,'','','',0,'','2021-04-13 21:46:42','','2021-04-13 22:09:55',_binary '\0'),(1116,'日志中心','',2,8,2,'log-center','log','infra/skywalking/log',0,'1','2021-04-26 22:35:45','1','2021-04-26 22:37:25',_binary '\0');
/*!40000 ALTER TABLE `sys_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_notice`
--

DROP TABLE IF EXISTS `sys_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `title` varchar(50) NOT NULL COMMENT '公告标题',
  `content` text NOT NULL COMMENT '公告内容',
  `notice_type` tinyint(4) NOT NULL COMMENT '公告类型（1通知 2公告）',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='通知公告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_notice`
--

LOCK TABLES `sys_notice` WRITE;
/*!40000 ALTER TABLE `sys_notice` DISABLE KEYS */;
INSERT INTO `sys_notice` VALUES (1,'温馨提醒：2018-07-01 若依新版本发布啦','新版本内容',2,0,'admin','2021-01-05 17:03:48','','2021-01-05 17:03:48',_binary '\0'),(2,'维护通知：2018-07-01 若依系统凌晨维护','维护内容',1,0,'admin','2021-01-05 17:03:48','','2021-01-05 17:03:48',_binary '\0'),(3,'1133','<p>222333</p>',1,0,'','2021-01-13 05:24:52','','2023-01-29 03:09:12',_binary '\0');
/*!40000 ALTER TABLE `sys_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_post`
--

DROP TABLE IF EXISTS `sys_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_post` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `code` varchar(64) NOT NULL COMMENT '岗位编码',
  `name` varchar(50) NOT NULL COMMENT '岗位名称',
  `sort` int(4) NOT NULL COMMENT '显示顺序',
  `status` tinyint(4) NOT NULL COMMENT '状态（0正常 1停用）',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='岗位信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_post`
--

LOCK TABLES `sys_post` WRITE;
/*!40000 ALTER TABLE `sys_post` DISABLE KEYS */;
INSERT INTO `sys_post` VALUES (1,'ceo','董事长',1,0,'','admin','2021-01-05 17:03:48','1','2021-03-14 20:39:03',_binary '\0'),(2,'se','项目经理',2,0,'','admin','2021-01-05 17:03:48','1','2021-03-14 20:39:05',_binary '\0'),(3,'hr','人力资源',3,0,'','admin','2021-01-05 17:03:48','','2021-01-05 17:03:48',_binary '\0'),(4,'user','普通员工',4,0,'','admin','2021-01-05 17:03:48','','2021-01-05 17:03:48',_binary '\0'),(5,'test','测试岗位',0,1,'132','','2021-01-07 15:07:44','','2021-01-07 15:10:35',_binary '');
/*!40000 ALTER TABLE `sys_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `name` varchar(30) NOT NULL COMMENT '角色名称',
  `code` varchar(100) NOT NULL COMMENT '角色权限字符串',
  `sort` int(4) NOT NULL COMMENT '显示顺序',
  `data_scope` tinyint(4) NOT NULL DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限 3：本部门数据权限 4：本部门及以下数据权限）',
  `data_scope_dept_ids` varchar(500) NOT NULL DEFAULT '' COMMENT '数据范围(指定部门数组)',
  `status` tinyint(4) NOT NULL COMMENT '角色状态（0正常 1停用）',
  `type` tinyint(4) NOT NULL COMMENT '角色类型',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COMMENT='角色信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (1,'超级管理员','admin',1,1,'',0,1,'超级管理员','admin','2021-01-05 17:03:48','','2021-01-06 12:40:20',_binary '\0'),(2,'普通角色','common',2,2,'',0,1,'普通角色','admin','2021-01-05 17:03:48','','2021-01-06 11:46:58',_binary '\0'),(101,'测试账号','test',0,2,'[104]',0,2,'132','','2021-01-06 13:49:35','1','2021-03-14 22:17:20',_binary '\0');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_menu`
--

DROP TABLE IF EXISTS `sys_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增编号',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `menu_id` bigint(20) NOT NULL COMMENT '菜单ID',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8mb4 COMMENT='角色和菜单关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_menu`
--

LOCK TABLES `sys_role_menu` WRITE;
/*!40000 ALTER TABLE `sys_role_menu` DISABLE KEYS */;
INSERT INTO `sys_role_menu` VALUES (1,2,1,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(2,2,2,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(3,2,3,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(4,2,4,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(5,2,100,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(6,2,101,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(7,2,102,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(8,2,103,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(9,2,104,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(10,2,105,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(11,2,106,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(12,2,107,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(13,2,108,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(14,2,109,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(15,2,110,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(16,2,111,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(17,2,112,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(18,2,113,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(19,2,114,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(20,2,115,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(21,2,116,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(22,2,500,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(23,2,501,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(24,2,1000,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(25,2,1001,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(26,2,1002,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(27,2,1003,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(28,2,1004,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(29,2,1005,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(30,2,1006,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(31,2,1007,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(32,2,1008,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(33,2,1009,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(34,2,1010,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(35,2,1011,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(36,2,1012,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(37,2,1013,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(38,2,1014,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(39,2,1015,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(40,2,1016,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(41,2,1017,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(42,2,1018,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(43,2,1019,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(44,2,1020,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(45,2,1021,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(46,2,1022,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(47,2,1023,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(48,2,1024,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(49,2,1025,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(50,2,1026,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(51,2,1027,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(52,2,1028,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(53,2,1029,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(54,2,1030,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(55,2,1031,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(56,2,1032,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(57,2,1033,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(58,2,1034,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(59,2,1035,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(60,2,1036,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(61,2,1037,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(62,2,1038,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(63,2,1039,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(64,2,1040,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(65,2,1041,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(66,2,1042,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(67,2,1043,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(68,2,1044,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(69,2,1045,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(70,2,1046,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(71,2,1047,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(72,2,1048,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(73,2,1049,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(74,2,1050,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(75,2,1051,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(76,2,1052,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(77,2,1053,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(78,2,1054,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(79,2,1055,'','2021-01-06 17:28:04','','2021-01-06 17:48:51',_binary ''),(80,2,1056,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(81,2,1057,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(82,2,1058,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(83,2,1059,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(84,2,1060,'','2021-01-06 17:28:04','','2021-01-06 17:28:04',_binary '\0'),(169,101,1001,'','2021-01-21 02:15:01','','2021-01-21 03:04:50',_binary ''),(170,101,1,'','2021-01-21 02:39:45','','2021-01-21 03:13:11',_binary ''),(171,101,100,'','2021-01-21 02:39:45','','2021-01-21 03:13:11',_binary ''),(172,101,1024,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(173,101,1025,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(174,101,1026,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(175,101,1027,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(176,101,1028,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(177,101,1029,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(178,101,1030,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(179,101,1036,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(180,101,1037,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(181,101,1038,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(182,101,1039,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(183,101,1040,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(184,101,1042,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(185,101,1043,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(186,101,1045,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(187,101,1063,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(188,101,1064,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(189,101,1065,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(190,101,1007,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(191,101,1008,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(192,101,1009,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(193,101,1010,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(194,101,1011,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(195,101,1012,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(196,101,1013,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(197,101,1014,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(198,101,1015,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(199,101,1016,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(200,101,1017,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(201,101,1018,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(202,101,1019,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(203,101,1020,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(204,101,1021,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(205,101,1022,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(206,101,1023,'','2021-01-21 03:04:50','','2021-01-21 03:07:43',_binary ''),(207,101,1001,'','2021-01-21 03:07:43','','2021-01-21 03:13:11',_binary ''),(208,101,1002,'','2021-01-21 03:07:43','','2021-01-21 03:10:08',_binary ''),(209,101,1002,'','2021-01-21 03:11:17','','2021-01-21 03:13:11',_binary ''),(210,101,1,'','2021-01-21 03:13:21','','2021-01-21 03:13:21',_binary '\0'),(211,101,1001,'','2021-01-21 03:13:21','','2021-01-21 03:13:40',_binary ''),(212,101,100,'','2021-01-21 03:13:21','','2021-01-21 03:13:40',_binary ''),(213,101,1008,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(214,101,1009,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(215,101,1010,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(216,101,1011,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(217,101,1012,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(218,101,101,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(219,101,1063,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(220,101,1064,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(221,101,1065,'','2021-01-21 03:13:40','','2021-01-21 03:23:14',_binary ''),(222,101,100,'','2021-01-21 03:23:14','','2021-01-21 03:23:27',_binary ''),(223,101,1001,'','2021-01-21 03:23:14','','2021-01-21 03:23:27',_binary ''),(224,101,1002,'','2021-01-21 03:23:14','','2021-01-21 03:23:27',_binary ''),(225,101,1003,'','2021-01-21 03:23:14','','2021-01-21 03:23:27',_binary ''),(226,101,1004,'','2021-01-21 03:23:14','','2021-01-21 03:23:27',_binary ''),(227,101,1005,'','2021-01-21 03:23:14','','2021-01-21 03:23:27',_binary ''),(228,101,1006,'','2021-01-21 03:23:14','','2021-01-21 03:23:27',_binary ''),(229,101,1007,'','2021-01-21 03:23:14','','2021-01-21 03:23:27',_binary ''),(230,101,1008,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0'),(231,101,1009,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0'),(232,101,1010,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0'),(233,101,1011,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0'),(234,101,1012,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0'),(235,101,101,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0'),(236,101,1063,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0'),(237,101,1064,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0'),(238,101,1065,'','2021-01-21 03:23:27','','2021-01-21 03:23:27',_binary '\0');
/*!40000 ALTER TABLE `sys_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(30) NOT NULL COMMENT '用户账号',
  `password` varchar(100) NOT NULL DEFAULT '' COMMENT '密码',
  `nickname` varchar(30) NOT NULL COMMENT '用户昵称',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `dept_id` bigint(20) DEFAULT NULL COMMENT '部门ID',
  `post_ids` varchar(255) DEFAULT NULL COMMENT '岗位编号数组',
  `email` varchar(50) DEFAULT '' COMMENT '用户邮箱',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机号码',
  `sex` tinyint(4) DEFAULT '0' COMMENT '用户性别',
  `avatar` varchar(100) DEFAULT '' COMMENT '头像地址',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `login_ip` varchar(50) DEFAULT '' COMMENT '最后登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '最后登录时间',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COMMENT='用户信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,'admin','$2a$10$0acJOIk2D25/oC87nyclE..0lzeu9DtQ/n3geP4fkun/zIVRhHJIO','芋道源码','管理员',103,'[1]','aoteman@126.com','15612345678',1,'http://api-dashboard.yudao.iocoder.cn/api/infra/file/get/5e8609290e915c4fa8b08e67.jpg',0,'127.0.0.1','2021-01-05 17:03:47','admin','2021-01-05 17:03:47','1','2021-05-02 23:03:24',_binary '\0'),(2,'ry','$2a$10$7JB720yubVSZvUI0rEqK/.VqGOZTH.ulu33dHOiBE8ByOhJIrdAu2','若依','测试员',105,'[2]','ry@qq.com','15666666666',1,'',0,'127.0.0.1','2021-01-05 17:03:47','admin','2021-01-05 17:03:47','','2021-04-01 04:50:36',_binary ''),(100,'yudao','$2a$10$11U48RhyJ5pSBYWSn12AD./ld671.ycSzJHbyrtpeoMeYiw31eo8a','芋道','不要吓我',100,'[1]','yudao@iocoder.cn','15601691300',1,'',1,'',NULL,'','2021-01-07 09:07:17','1','2021-03-14 22:35:17',_binary '\0'),(103,'yuanma','','源码',NULL,100,NULL,'yuanma@iocoder.cn','15601701300',0,'',0,'',NULL,'','2021-01-13 23:50:35','','2021-01-13 23:50:35',_binary '\0'),(104,'test','$2a$10$.TOFpaIiI3PzEwkGrNq0Eu6Cc3rOqJMxTb1DqeSEM8StxaGPBRKoi','测试号',NULL,100,'[]','','15601691200',1,'',0,'',NULL,'','2021-01-21 02:13:53','1','2021-03-14 22:36:38',_binary '\0');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增编号',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bit(1) DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='用户和角色关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_role`
--

LOCK TABLES `sys_user_role` WRITE;
/*!40000 ALTER TABLE `sys_user_role` DISABLE KEYS */;
INSERT INTO `sys_user_role` VALUES (1,1,1,'',NULL,'',NULL,_binary '\0'),(2,2,2,'',NULL,'',NULL,_binary '\0'),(3,100,1,'',NULL,'',NULL,_binary ''),(4,100,101,'',NULL,'',NULL,_binary '\0'),(5,100,1,'',NULL,'',NULL,_binary '\0'),(6,100,2,'',NULL,'',NULL,_binary '\0'),(7,104,101,'',NULL,'',NULL,_binary '\0');
/*!40000 ALTER TABLE `sys_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'wcs-boot-vue'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-03 15:42:49
